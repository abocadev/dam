package dev.boca.actividad1;
public class Actividad1 {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
