package dev.boca.actividad1.Pregunta2;
public class Avioneta extends Thread{
    GestorDespegue gd;
    
    public Avioneta(GestorDespegue gd){
        this.gd = gd;
    }
    
    @Override
    public void run(){
        try {
            gd.despegarAvioneta();
        } catch (InterruptedException e) {
        }
    }
}
