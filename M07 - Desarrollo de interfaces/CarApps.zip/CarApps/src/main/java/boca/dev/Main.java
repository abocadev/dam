package boca.dev;

public class Main {
    public static void main(String[] args){
        boca.dev.Screens.PantallaInicio.start();
    }
}