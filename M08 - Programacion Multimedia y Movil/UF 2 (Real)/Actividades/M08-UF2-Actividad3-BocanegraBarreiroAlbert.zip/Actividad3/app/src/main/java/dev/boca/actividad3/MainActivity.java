package dev.boca.actividad3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Este es el main activity de la aplicacion que no hace nada
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}