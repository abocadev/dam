package dev.boca.ficheros;

public class E032metodoEstatico {
    
    static int valor = 1024;
    
    static int dividir2(){
        return valor/2;
    }
}
