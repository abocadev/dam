package ChenXinyiContacto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class XCMain{
    
    private XCContacto contacto;
    private Scanner entrada = new Scanner(System.in);
    private static boolean salir = false;
    
    public static void main(String[] args) {
        try(
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ChenXinyi.bin"));
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ChenXinyi.bin"));
        ){
            while(!salir){
                System.out.println("Selecciona una de estas opciones:");
                System.out.println("1 - Añadir contactos");
                System.out.println("2 - Buscar contactos");
                System.out.println("3 - Borrar contactos");
                System.out.println("4 - Mostrar contactos");
                System.out.println("5 - Importar contactos");
                System.out.println("6 - Salir");

                int opcion = 0;
                boolean auxsalir = false;
                while(!auxsalir){
                    if(entrada.hasNextInt()){
                        opcion = entrada.nextInt();
                        if(opcion > 0 && opcion < 7){
                            auxsalir = true;
                        }else{
                            System.out.println("Tienes que introducir un numero del 1 al 5.");
                        }
                    }else{
                        entrada.nextLine();
                        System.out.println("Has introducido un valor incorrecto.");
                        mostrarOpciones();
                    }
                }

                switch (opcion) {
                    case 1:
                        String nombre = "", empresa = "", email = "", telefono = "";
                        System.out.println("Introduce el nombre: ");
                        nombre = entrada.next();

                        System.out.println("Introduce el nombre de la empresa: ");
                        empresa = entrada.next();

                        System.out.println("Introduce el correo electronico: ");
                        email = entrada.next();

                        System.out.println("Introduce el numero de telefono: ");
                        telefono = entrada.nextInt();

                        contacto = new XCContacto(nombre, empresa, email, telefono);
                        oos.writeObject(contacto);
                        break;
                    case 2:
                        int nResultados = 0;
                        String busqueda = "";
                        System.out.println("Introduce un nombre del contacto a buscar: ");
                        busqueda = entrada.next();    

                        while(true){
                            XCContacto contacto = (XCContacto)ois.readObject();
                            if(busqueda.equals(contacto.getNombre())){
                                nResultados++;
                            }
                        }

                        System.out.println("Se han encontrado " + nResultados);
                        break;
                    case 3:
                        System.out.println("Contacto eliminado")
                        break;
                    case 4:
                        int num  = 1;
                        while (true) {
                            XCContacto aux = (XCContacto)ois.readObject();
                            System.out.println("\n---------------------------");
                            System.out.println("Nombre: " + aux.getNombre());
                            System.out.println("Email: " + aux.getEmail());
                            System.out.println("Empresa: " + aux.getEmpresa());
                            System.out.println("Telefono: " + aux.getTelefono());
                        }
                        break;
                    case 5:
                        salir = true;
                        break;
                    default:
                        System.out.println("ERROR");
                        break;
                }
            }
        }catch(Exception e){
        }
                
    }
}