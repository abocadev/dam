package tienda;

public class BocanegraAlbertMain {
    public static void main(String[] args) {
        BocanegraAlbertTienda tienda = new BocanegraAlbertTienda("TIENDA MOLONA");
        tienda.setVisible(true);
    }   
}
